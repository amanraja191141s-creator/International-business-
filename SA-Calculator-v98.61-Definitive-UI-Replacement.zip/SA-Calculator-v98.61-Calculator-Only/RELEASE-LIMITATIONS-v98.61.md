# Release limitations — v98.61

- This release fixes the source-to-production CSS path and adds a cache namespace migration, but physical Android rendering still needs device validation.
- No APK was assembled or installed on a physical device in this environment.
- No claim of zero lag or zero bugs is made; performance depends on device, WebView version and screen workload.
- Existing user-selected theme mode and accent are preserved intentionally; users can choose Violet in the palette if they want the reference default.
