# SA Calculator v98.52 — Home screen redesign

## Approved reference implementation

This release replaces the previous Home screen presentation with the approved dark navy / blue SA Calculator concept while preserving the existing calculator DOM, calculation handlers, expression editing, result preview, and existing tool engines.

### Home layout
- App header: 64dp target; drawer at left, existing SA Calculator logo and title, History action and overflow menu at right. Brand tagline hidden to reduce clutter.
- Expression display: inset rounded panel, 2px subtle border, expression aligned to the right and result emphasized beneath it.
- Keypad: four equal columns and five rows. The zero key spans two columns. AC, division, multiplication, subtraction, addition and equals use blue primary styling; +/- and percent use utility styling; digits and decimal use raised navy keys.
- Bottom navigation: five equal destinations — Home, History, Favorites, Tools and Settings.
- Individual tools retain their existing contextual screen/navigation behavior.

### Responsive sizing
- Header: 64dp (56dp on short windows).
- Bottom navigation: 78dp (68dp on short windows).
- Display: approximately 25% of available Home workspace, constrained to 142–228dp; compact fallback 126dp minimum.
- Keypad: fills remaining workspace; 4 × 5 grid; 8dp standard gap, 5–6dp compact; visual key cells fill grid cells and retain 48dp minimum touch target.
- Key radius: 19dp standard, 14–16dp compact.
- Expression: clamp(20px, 5.6vw, 29px); result: clamp(42px, 11vw, 66px).

### Behavior preserved/updated
- Existing calculator button data attributes and event handlers are unchanged.
- Header History action opens the existing accessible History modal.
- Overflow still opens the existing navigation drawer.
- Home nav label replaces Calculator; existing destination routing remains intact.
- Light theme receives a contrast-safe counterpart without changing geometry.
- Landscape and short-height layouts have compact responsive fallbacks.

### Explicit limitations
A generated visual concept is not a device screenshot. Physical Android/WebView screenshot, touch, and performance validation remain separate release checks.
