# SA Calculator v98.55 — QA results

## Passed locally
- 341/341 automated regression tests (`npm test`).
- `npm run build:web`: 30 required runtime assets verified and 18 CSS source layers consolidated.
- JavaScript syntax checks: `assets/js/app.js`, `service-worker.js`, `scripts/prepare-android-web.mjs`, and `scripts/patch-android-native.mjs`.
- PostCSS parsing: `assets/css/rebuild-v98.55.css`, consolidated `assets/css/app.css`, and generated `www/assets/css/app.css`.
- GitHub Actions YAML parsing for both `.github/workflows/main.yml` and `SA-Calculator-v98.55-Android-Workflow.yml`.
- JSON parsing: package manifest, PWA manifest and Capacitor config.
- Source and generated CSS layers synchronized; workflow copies byte-identical.
- v98.54 Home CSS layer removed from source and active build chain.
- Keypad geometry regression checks: 426 CSS px reference width -> 87.5px row height; 354 CSS px compact width -> 72.7px row height; all 19 calculation hooks retained; 48px minimum key dimensions retained.
- ZIP archive integrity checked after packaging.

## Not yet verified
- Hosted GitHub Actions Android Gradle build / APK output.
- Installation and runtime behavior on a physical Android phone.
- Pixel-perfect screenshot comparison on the user's device and font scale.
- Measured frame-time, memory and long-session performance.

No claim of completely bug-free or zero-lag physical-device behavior is made until those checks complete.
