# Release verification — v98.33 (final hardened package)

- Package: `1.98.33-v98.33`
- Android versionCode expected by workflow: `1098033`
- Service worker cache: `sa-calculator-v98-33-premium-system-rebuild`
- All runtime versions and four workflow copies synchronized.
- New authoritative stylesheet: `assets/css/rebuild-v98.33.css`.
- Existing calculation engines, storage/data behavior and prior compatibility layers retained.
- Automated regression suite: 255 passed, 0 failed.
- Android web bundle rebuilt and required assets verified.
- Four YAML workflow copies parsed successfully and are byte-identical.
- Service-worker navigation now uses the cached app shell for transient HTTP 5xx failures while preserving genuine 4xx responses.

## Validation boundary

The source ZIP and Android web bundle are validated. A physical Android APK was not built in this environment: the supplied source archive does not contain a generated `android/` Gradle project, and this environment has not run the GitHub Actions Android SDK/JDK build. Install/run QA on a physical device, live currency provider checks, OEM keyboard behavior, FPS/jank, memory, battery and long-session stability remain pending. Do not interpret automated source tests as a universal bug-free or lag-free certification.
