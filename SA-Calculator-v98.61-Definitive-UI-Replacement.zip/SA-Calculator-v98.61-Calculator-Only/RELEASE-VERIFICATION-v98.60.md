# Release verification v98.60

Source version, manifest version, HTML metadata, runtime APP_VERSION, service-worker cache identity and Android workflow version checks are synchronized at `1.98.60-v98.60` / `1098060`.
