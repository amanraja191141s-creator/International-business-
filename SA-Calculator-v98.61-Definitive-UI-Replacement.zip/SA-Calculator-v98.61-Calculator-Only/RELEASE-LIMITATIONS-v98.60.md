# v98.60 release limitations

- The redesign is based on the supplied reference screenshots, but exact pixel parity across every Android device, screen density, font scale, and WebView version is not guaranteed.
- Automated source/build tests pass; this environment did not assemble, install, or exercise an APK on a physical Android device.
- Performance claims such as fully lag-free operation require measurements on target devices and are not asserted here.
- Currency values remain dependent on the configured data providers and their availability/freshness.
- Older installed builds may retain local app data; removing vault source code from this calculator-only package does not securely erase data already stored by a previous installation.
