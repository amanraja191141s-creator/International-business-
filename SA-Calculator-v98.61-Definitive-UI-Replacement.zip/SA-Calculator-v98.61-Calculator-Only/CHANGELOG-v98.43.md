# SA Calculator v98.43 — Premium Tools Menu Rebuild

## User-requested replacement
- Replaced the old Tools-menu drawer/category list and its Quick Access section with a dedicated Tools screen matching the supplied premium two-column visual direction.
- Added 18 destination cards: Calculator, Currency Converter, Unit Converter, Discount, Percentage, Sales Tax, Body Metrics, Date Calculator, Fuel Cost, Fuel Efficiency, Grade Average, Hex Converter, Loan Calculator, Savings Calculator, Tip Calculator, Unit Price, World Time, and Settings.
- Added a searchable tools grid with clear-search and no-results states.
- Matched the Tools header treatment with the SA Calculator brand at left and dedicated Search / More actions at right; Search focuses the grid search and More opens the compact utility drawer.
- Kept the hamburger drawer as a compact utility drawer for Help, Scientific Calculator, History, and Settings; it no longer duplicates the categorized tools directory.
- Changed bottom navigation to Calculator, History, Favorites, Tools. Settings remains available as a Tools card and drawer utility action.
- Kept the scientific calculator reachable from the drawer and calculator's inline scientific action; the 18-card grid remains faithful to the supplied reference.

## Implementation and release
- Added `assets/css/rebuild-v98.43.css` with responsive two-column cards, compact 360px layout, theme-token-based surfaces, keyboard focus, touch feedback, and reduced-motion handling.
- Added the new stylesheet to the single production CSS build and Android bundle pipeline.
- Bumped app release to `1.98.43-v98.43`, Android versionCode `1098043`, and Service Worker cache namespace `sa-calculator-v98-43-premium-tools-screen`.
- Synchronized the active GitHub Actions workflow and downloadable YAML copy.
- Added five regression tests for drawer removal, 18-card destination integrity, bottom navigation, responsive CSS/offline bundle inclusion, and release identity.
