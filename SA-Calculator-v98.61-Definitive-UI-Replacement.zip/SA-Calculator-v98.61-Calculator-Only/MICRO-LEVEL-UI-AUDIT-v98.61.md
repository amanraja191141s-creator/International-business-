# Micro-level UI audit — v98.61

## Root cause addressed
The prior v98.60 layer mainly recoloured existing elements. It did not consistently replace the older component geometry and the production stylesheet URL remained stable. This release adds a final v98.61 source layer, explicit component selectors, a cache-busted stylesheet URL, and a new service-worker cache namespace.

## UI changes
- Calculator: rebuilt display hierarchy, spacing, keypad button geometry, utility/operator/equal states, and responsive row sizing.
- Scientific: removed the legacy beige display skin; standardized dark and light display treatments.
- History: card-based list, consistent spacing and clear action.
- Tools: charcoal grid cards and violet icon treatment.
- Currency/units: consistent dark cards and input controls, with light-mode counterparts.
- Settings/theme: rectangular swatches, readable labels, violet active state.
- Navigation: persistent charcoal bottom bar with clear active state.

## Cache and build corrections
- Added `rebuild-v98.61.css` to the build's ordered CSS source list.
- Updated index stylesheet URL to `app.css?v=9861`.
- Updated service-worker cache namespace and precache URL.
- Updated release identity to 1.98.61-v98.61 / Android versionCode 1098061 in workflow gates.

## Scope
The existing screens, labels, DOM IDs, buttons and event hooks are retained. This is a UI layer replacement, not a rewrite of calculation or conversion algorithms.
