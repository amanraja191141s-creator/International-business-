# v98.60 UI redesign

Rebuilt the visual layer around the supplied references: charcoal/near-black surfaces, violet default accent, 12 selectable accent swatches, compact rounded calculator keys, distinct scientific keypad, card-based history, and consistent converter/settings surfaces. Existing calculator, scientific, history, currency, unit conversion, tools, favorites, and settings DOM/functionality are retained.

Palette choices now update the CSS tokens and persist through the existing settings storage. Appearance mode remains independently selectable (dark/light/system).

This is a web UI/source redesign; it does not claim pixel-identical rendering on every Android WebView or physical device.
