# SA Calculator v98.59 — Calculator-only release

- Removed the Private Vault drawer entry and complete overlay UI.
- Removed the vault JavaScript runtime, encrypted IndexedDB/backup logic, and vault-only CSS.
- Removed vault assets from the web build requirements and service-worker precache list.
- Removed vault-specific tests and replaced them with calculator-only release guards.
- Removed the vault-only Android FLAG_SECURE window restriction; retained edge-to-edge and system-bar styling.
- Synchronized package, manifest, HTML, Android version identity, cache namespace, and CI workflow.
- Preserved calculator, scientific functions, history, tools, converters, themes, localization, and existing Android branding/build scripts.

Note: Removing source code does not securely erase old vault records from an already-installed app's IndexedDB. Clear app data/uninstall separately if you intend to remove previously stored local data; this is not a forensic erase guarantee.
