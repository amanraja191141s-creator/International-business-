# SA Calculator v98.60 — UI audit and changes

## Reference direction applied
- Charcoal/near-black application shell and card surfaces
- Violet default accent with 12 selectable colour swatches
- Compact rounded basic-calculator keypad with distinct clear/operator/equal states
- Separate scientific display and function-key styling
- Card-based History list and consistent Currency/Unit Converter, Tools, Settings and bottom-navigation surfaces
- Light, dark and follow-system modes remain independent from the accent colour

## Functionality retained
Basic and scientific calculation engines, history, currency converter, unit converter, all registered tools, favourites, localization, settings, and Android/Capacitor build configuration remain in the source. The Private Vault is not present in the runtime UI, JS modules, styles, or offline cache.

## Code and release cleanup
- Added one ordered CSS layer (`rebuild-v98.60.css`) and included it in the Android web bundle build.
- Restored real palette selection rather than forcing every palette tap back to one hard-coded blue value.
- Removed forced-dark/forced-blue runtime overrides; validated accent values and preserved saved appearance mode.
- Added explicit release identity/cache namespace `1.98.60-v98.60`.
- Added regression coverage for the redesign, palette, appearance modes, and calculator-only scope.

## Validation boundary
The automated suite and web bundle build were run locally. No APK build, physical-device test, accessibility lab audit, or frame-time benchmark was performed in this environment.
