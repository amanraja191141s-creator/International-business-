'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const html = fs.readFileSync(require('node:path').join(__dirname, '..', 'index.html'), 'utf8');
const js = fs.readFileSync(require('node:path').join(__dirname, '..', 'assets/js/app.js'), 'utf8');
test('scientific memory controls exist only on the standalone Scientific Calculator screen', () => {
  const sci = html.slice(html.indexOf('id="screen-scientific"'), html.indexOf('id="screen-currencies"'));
  const basic = html.slice(html.indexOf('id="screen-calc"'), html.indexOf('id="screen-scientific"'));
  for (const key of ['MC','MR','M+','M-','MS']) assert.match(sci, new RegExp('data-sci-memory="' + key.replace('+','\\+') + '"'));
  assert.doesNotMatch(basic, /data-memory|memory-indicator|data-sci-memory/);
  assert.match(js, /sa_scientific_memory_v1/);
  assert.match(js, /persistScientificMemory/);
});
test('scientific memory recall is isolated from the basic calculator expression and result state', () => {
  const init = js.slice(js.indexOf('function initScientific()'), js.indexOf('const CURRENCY_CATALOG'));
  assert.match(init, /sci\.memory/);
  assert.match(init, /op === 'MR' && sci\.hasMemory/);
  assert.doesNotMatch(init, /STATE\.calcExpr|STATE\.calcVal|STATE\.calcRawValue/);
});
