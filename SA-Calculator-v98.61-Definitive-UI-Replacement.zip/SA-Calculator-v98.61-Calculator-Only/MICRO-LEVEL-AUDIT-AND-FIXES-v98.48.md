# SA Calculator v98.48 — Micro-level video audit

## Source-derived observations from the supplied 84.3-second recording
1. Scientific screen frame 7/8: only the top row of the numeric keypad was visible; the remaining numeric rows and memory row were clipped below the bottom navigation. The function bank and keypad consumed more vertical space than the viewport.
2. Scientific expression frame 7/8: long nested expressions were clipped in the single-line input; caret/scroll positioning was not stable because render assigned `editor.value` on every input event, including when unchanged.
3. Tools frame 13/16: category controls and tool cards visually overlapped; cards had inconsistent apparent widths/columns. The new CSS explicitly isolates the search and category rows and forces a 2-column grid.
4. Basic calculator frame 25: display occupies a relatively large blank area compared with the keypad. Existing responsive display sizing is retained; this release avoids changing arithmetic behavior.
5. Currency frame 21: conversion values and pair are readable, but provider/rate metadata is dense. Only its typography and spacing are adjusted; rate calculations/providers are untouched.
6. History/Favorites/Settings frames: no unambiguous calculation or navigation failure is demonstrated by the sampled frames; their logic is preserved rather than changed speculatively.

## Implementation
- `assets/css/rebuild-v98.48.css`: isolated Tools layout, scientific viewport fit, scrollable scientific function bank, complete keypad sizing, and currency note readability.
- `assets/js/app.js`: preserve scientific input value/caret when unchanged; keep horizontal caret position visible.
- `index.html`: cap scientific expression input at 250 characters.
- `scripts/prepare-android-web.mjs`: compile v98.48 CSS layer into Android bundle.
- `service-worker.js`: new cache identity to prevent stale CSS.
- `.github/workflows/main.yml` and downloadable YAML: synchronized release version.

## Deliberately unchanged
- Basic calculator arithmetic engine and keypad event contract.
- Scientific math parser, angle conversion, memory, history and independent storage.
- Currency provider/rate calculations and unit-conversion calculations.
- Existing tool destination IDs and bottom navigation.

## Verification boundary
Automated source tests and generated web bundle are checked in this workspace. A hosted APK build and physical Android screenshot/performance test are not claimed unless actually run.
