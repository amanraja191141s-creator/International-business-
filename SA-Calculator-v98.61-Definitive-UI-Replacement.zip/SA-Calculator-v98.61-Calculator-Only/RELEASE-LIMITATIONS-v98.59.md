# v98.59 release limitations

- Source removal does not erase previously stored vault data from an installed app's IndexedDB.
- No forensic secure-erasure guarantee is made for flash storage.
- No physical Android device matrix, accessibility audit, or performance benchmark is claimed by source-level tests.
- Debug APK generation requires Android SDK/Gradle dependencies in the build environment.
