# SA Calculator v98.60 — Charcoal/Violet Calculator

A mobile-first calculator workspace with scientific calculations, calculation history, themes, localization, tools, and converters. The project includes a Capacitor Android wrapper and a GitHub Actions workflow for validation and debug APK builds.

## Build

- Install Node.js 22 and npm.
- Run `npm install`.
- Run `npm test` for regression checks.
- Run `npm run build:web` to create the Android web bundle in `www/`.
- Run `npx cap add android` once, then `npx cap sync android`.
- Run `npm run android:brand` after Android project generation.
- Build with `cd android && ./gradlew assembleDebug`.

Release identity: `1.98.60-v98.60`; Android versionCode: `1098060`.

The UI follows the supplied charcoal/black reference direction with a violet default accent and 12 selectable accent colours. Dark, light, and follow-system appearance modes are independent from the accent palette.

This release is calculator-only and includes the v98.60 UI redesign. Source cleanup does not migrate or erase data that may have been stored by an older installed build. Previously saved local data can remain in app storage until app data is cleared or the app is uninstalled; this is not a forensic secure-erasure guarantee.
