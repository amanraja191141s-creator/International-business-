# File-by-file release audit — v98.33 final hardened package

- `index.html`: version metadata and stylesheet order verified; original screen IDs and data hooks retained.
- `assets/css/rebuild-v98.33.css`: authoritative premium visual layer; compatibility CSS retained beneath it.
- `assets/js/app.js`: existing calculator/tool engines and event wiring retained; existing test coverage passes.
- `service-worker.js`: cache namespace and precache list verified; transient navigation HTTP 5xx now falls back to cached app shell, while 4xx responses remain visible.
- `scripts/prepare-android-web.mjs`: required runtime assets checked and Capacitor `www/` rebuilt.
- `package.json`, `manifest.webmanifest`, HTML and runtime version identifiers: synchronized at `1.98.33-v98.33`.
- `.github/workflows/main.yml`, `android-apk.yml`, workflow aliases and supplied root YAML: parsed and byte-identical; expected Android versionCode `1098033`.
- `tests/service-worker-navigation-fallback.test.js`: added regression checks for 5xx fallback and 4xx pass-through.
- `www/`: regenerated from current source after final service-worker change.

## Validation

- `npm test`: 255 passed, 0 failed.
- `npm run build:web`: passed; 12 required runtime assets verified.
- `node --check service-worker.js`: passed.
- YAML parse: all four workflow copies passed.
- HTTP smoke checks: see release verification and final QA notes.

## Not certified here

No generated Android Gradle project/APK was supplied or built in this environment. Physical-device visual comparison, OEM keyboard checks, live currency provider/network checks, FPS/jank, memory, battery and long-session testing require Android device/CI validation.
