# v98.60
- Replaced the blue neon visual skin with charcoal/black and violet reference styling.
- Added 12 working accent palette swatches.
- Restyled calculator, scientific keypad, history, converter, tools, settings, and bottom navigation.
- Preserved calculator and tool workflows; no Private Vault code reintroduced.
